# detec_objetos > 2025-07-20 2:04pm
https://universe.roboflow.com/adegax/detec_objetos

Provided by a Roboflow user
License: CC BY 4.0

