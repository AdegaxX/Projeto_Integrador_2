# acessorios > Roboflow Instant 2 [Eval]
https://universe.roboflow.com/acessoriofacial/acessorios

Provided by a Roboflow user
License: CC BY 4.0

